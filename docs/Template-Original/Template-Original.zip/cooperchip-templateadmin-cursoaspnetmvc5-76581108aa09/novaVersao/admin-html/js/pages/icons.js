//------------- icons.js -------------//
$(document).ready(function() {

	// Search for icon
	$('.icon-search input').val('').quicksearch('.col-lg-3', {
        'removeDiacritics': true,
    });

});